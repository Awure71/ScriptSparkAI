import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, Download } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ScriptDisplayProps {
  script: any;
  isGenerating: boolean;
}

export default function ScriptDisplay({ script, isGenerating }: ScriptDisplayProps) {
  const { toast } = useToast();

  const handleCopy = async () => {
    if (!script?.generatedContent?.sections) return;
    
    const textContent = script.generatedContent.sections.map((section: any) => 
      `${section.title} (${section.duration})\n${section.content}\n\nVisual: ${section.visualPrompt}\n`
    ).join('\n---\n\n');
    
    try {
      await navigator.clipboard.writeText(textContent);
      toast({
        title: "Copied!",
        description: "Script copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  const handleExport = (format: string) => {
    if (!script?.script?.id) return;
    
    const link = document.createElement('a');
    link.href = `/api/scripts/${script.script.id}/export/${format}`;
    link.download = `${script.script.topic}_script.${format === 'json' ? 'json' : 'txt'}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Export Started",
      description: `Downloading ${format.toUpperCase()} file...`,
    });
  };

  return (
    <Card className="shadow-sm" data-testid="card-script-display">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-bold">Generated Script</h3>
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleCopy}
              disabled={!script}
              title="Copy Script"
              data-testid="button-copy-script"
            >
              <Copy className="w-4 h-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => handleExport('text')}
              disabled={!script}
              title="Export"
              data-testid="button-export-script"
            >
              <Download className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      <CardContent className="p-6">
        {/* Loading State */}
        {isGenerating && (
          <div className="text-center py-12" data-testid="loading-state">
            <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Generating your viral script...</p>
          </div>
        )}

        {/* Generated Content */}
        {script?.generatedContent && !isGenerating && (
          <div className="space-y-6" data-testid="generated-content">
            {script.generatedContent.sections?.map((section: any, index: number) => (
              <div key={index} className="space-y-3">
                <h4 className="font-semibold text-lg mb-2">{section.title} ({section.duration})</h4>
                <div className="bg-secondary/50 rounded-lg p-4 mb-3">
                  <p className="font-medium">{section.content}</p>
                </div>
                <div className="bg-accent/50 rounded-lg p-3 text-sm">
                  <strong>Visual:</strong> {section.visualPrompt}
                </div>
              </div>
            ))}

            {/* Export Options */}
            <div className="border-t border-border pt-6">
              <h4 className="font-semibold mb-4">Export Options</h4>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="outline"
                  onClick={() => handleExport('text')}
                  className="flex items-center justify-center space-x-2"
                  data-testid="button-export-text"
                >
                  <i className="fas fa-file-alt"></i>
                  <span>Text Script</span>
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleExport('json')}
                  className="flex items-center justify-center space-x-2"
                  data-testid="button-export-json"
                >
                  <i className="fas fa-video"></i>
                  <span>JSON Format</span>
                </Button>
                <Button
                  variant="outline"
                  disabled
                  className="flex items-center justify-center space-x-2 opacity-50"
                  data-testid="button-export-capcut"
                >
                  <i className="fas fa-file-video"></i>
                  <span>CapCut (Soon)</span>
                </Button>
                <Button
                  variant="outline"
                  disabled
                  className="flex items-center justify-center space-x-2 opacity-50"
                  data-testid="button-export-premiere"
                >
                  <i className="fas fa-share"></i>
                  <span>Premiere (Soon)</span>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {!script && !isGenerating && (
          <div className="text-center py-12 text-muted-foreground" data-testid="empty-state">
            <p>Your generated script will appear here</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
