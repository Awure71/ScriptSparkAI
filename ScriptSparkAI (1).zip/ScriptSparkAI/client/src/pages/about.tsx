import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Users, Target, Sparkles, ArrowLeft, Crown } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/20 via-primary/10 to-background py-24">
        <div className="container mx-auto px-6 max-w-4xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-8" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            About <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">ScriptAI</span>
          </h1>
          <p className="text-xl text-foreground/80 leading-relaxed">
            Empowering content creators with AI-powered script generation for viral social media videos.
          </p>
        </div>
      </div>

      {/* Mission Section */}
      <div className="container mx-auto px-6 py-16 max-w-5xl">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Our Mission</h2>
            <p className="text-lg text-foreground/90 leading-relaxed mb-4">
              We believe every content creator deserves access to professional-quality script writing tools. ScriptAI was built to democratize video content creation by making AI-powered scriptwriting accessible to everyone.
            </p>
            <p className="text-lg text-foreground/90 leading-relaxed">
              Whether you're a YouTuber, TikToker, podcaster, or social media manager, we're here to help you create engaging, viral-worthy content faster than ever before.
            </p>
          </div>
          <div className="bg-gradient-to-br from-primary/10 to-primary/5 p-8 rounded-2xl border border-primary/20">
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Sparkles className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">AI-Powered</h3>
                  <p className="text-foreground/80">Leveraging cutting-edge AI technology to generate creative, engaging scripts</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Users className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">Creator-Focused</h3>
                  <p className="text-foreground/80">Built by creators, for creators, with features that actually matter</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Target className="w-8 h-8 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">Results-Driven</h3>
                  <p className="text-foreground/80">Optimized for engagement, retention, and viral potential</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gradient-to-br from-primary/5 to-background py-16">
        <div className="container mx-auto px-6 max-w-5xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-2">
                10K+
              </div>
              <div className="text-foreground/70">Scripts Generated</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-2">
                5K+
              </div>
              <div className="text-foreground/70">Active Creators</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-2">
                50+
              </div>
              <div className="text-foreground/70">Countries</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent mb-2">
                98%
              </div>
              <div className="text-foreground/70">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* Story Section */}
      <div className="container mx-auto px-6 py-16 max-w-3xl">
        <h2 className="text-3xl font-bold mb-6">Our Story</h2>
        <div className="space-y-4 text-lg text-foreground/90 leading-relaxed">
          <p>
            ScriptAI was born from a simple frustration: creating engaging video scripts was taking content creators hours of work that could be spent actually creating content.
          </p>
          <p>
            As content creators ourselves, we understood the struggle of staring at a blank page, trying to come up with the perfect hook, the right pacing, and compelling visual ideas. We knew there had to be a better way.
          </p>
          <p>
            Combining our expertise in AI technology and content creation, we built ScriptAI to solve this problem. Our platform uses advanced language models to understand what makes content viral and helps creators generate professional-quality scripts in minutes instead of hours.
          </p>
          <p>
            Today, thousands of creators use ScriptAI to streamline their content creation process, and we're just getting started.
          </p>
        </div>
      </div>

      {/* CTA Section */}
      <div className="container mx-auto px-6 py-16 max-w-4xl">
        <div className="p-12 rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-primary/5 border border-primary/30 text-center">
          <h2 className="text-3xl font-bold mb-4">Join Thousands of Creators</h2>
          <p className="text-lg text-foreground/80 mb-8 max-w-2xl mx-auto">
            Start creating viral-worthy video scripts today. Try 3 scripts free, then upgrade to Pro for unlimited access.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button size="lg" className="gradient-bg" data-testid="button-start-free">
                Start Free
              </Button>
            </Link>
            <Link href="/">
              <Button size="lg" variant="outline" className="border-primary/50" data-testid="button-view-pricing">
                <Crown className="w-4 h-4 mr-2" />
                View Pricing
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
