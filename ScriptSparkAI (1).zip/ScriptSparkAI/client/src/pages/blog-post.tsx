import { Link, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Clock, User, Share2, Crown } from "lucide-react";
import { getBlogPost, getAllPosts } from "@/data/blog-posts";

export default function BlogPost() {
  const [, params] = useRoute("/blog/:slug");
  const post = getBlogPost(params?.slug || "");
  const allPosts = getAllPosts();
  const relatedPosts = allPosts.filter(p => p.id !== post?.id && p.category === post?.category).slice(0, 3);

  if (!post) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Post Not Found</h1>
          <p className="text-muted-foreground mb-8">The article you're looking for doesn't exist.</p>
          <Link href="/blog">
            <Button>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-gradient-to-br from-primary/10 to-background py-8 border-b">
        <div className="container mx-auto px-6 max-w-4xl">
          <Link href="/blog">
            <Button variant="ghost" size="sm" data-testid="button-back-blog">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Blog
            </Button>
          </Link>
        </div>
      </div>

      {/* Article Hero */}
      <div className="container mx-auto px-6 py-12 max-w-4xl">
        <div className="mb-6">
          <span className="px-3 py-1 bg-primary/10 text-primary text-sm font-semibold rounded-full">
            {post.category}
          </span>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">{post.title}</h1>
        
        <div className="flex flex-wrap items-center gap-4 text-muted-foreground mb-8">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span>{post.author}</span>
          </div>
          <span>•</span>
          <span>{post.date}</span>
          <span>•</span>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>{post.readTime}</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-primary/20 to-primary/5 rounded-2xl h-64 md:h-96 flex items-center justify-center mb-12">
          <div className="text-8xl">
            {post.category === "Tutorials" && "🎓"}
            {post.category === "Best Practices" && "⭐"}
            {post.category === "Industry News" && "📰"}
            {post.category === "Creator Stories" && "🎬"}
          </div>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none mb-12">
          <div className="text-xl font-semibold text-foreground/90 mb-8 leading-relaxed">
            {post.excerpt}
          </div>
          <div className="whitespace-pre-wrap text-foreground/90 leading-relaxed space-y-6">
            {post.content.split('\n\n').map((paragraph, index) => {
              if (paragraph.startsWith('#')) {
                const level = paragraph.match(/^#+/)?.[0].length || 1;
                const text = paragraph.replace(/^#+\s*/, '');
                const className = level === 1 
                  ? "text-3xl font-bold mt-12 mb-6 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent"
                  : level === 2
                  ? "text-2xl font-bold mt-8 mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent"
                  : "text-xl font-semibold mt-6 mb-3";
                return <h2 key={index} className={className}>{text}</h2>;
              }
              
              if (paragraph.startsWith('**') && paragraph.endsWith(':**')) {
                const text = paragraph.replace(/\*\*/g, '');
                return <h3 key={index} className="text-lg font-bold mt-6 mb-3 text-foreground">{text}</h3>;
              }
              
              if (paragraph.match(/^[-•*]\s/)) {
                const items = paragraph.split('\n').map(item => item.replace(/^[-•*]\s/, ''));
                return (
                  <ul key={index} className="list-disc pl-6 space-y-2 my-4">
                    {items.map((item, i) => (
                      <li key={i} className="text-foreground/90">{item.replace(/\*\*/g, '')}</li>
                    ))}
                  </ul>
                );
              }
              
              if (paragraph.match(/^\d+\.\s/)) {
                const items = paragraph.split('\n').map(item => item.replace(/^\d+\.\s/, ''));
                return (
                  <ol key={index} className="list-decimal pl-6 space-y-2 my-4">
                    {items.map((item, i) => (
                      <li key={i} className="text-foreground/90">{item.replace(/\*\*/g, '')}</li>
                    ))}
                  </ol>
                );
              }
              
              if (paragraph.startsWith('✅') || paragraph.startsWith('❌')) {
                return <p key={index} className="my-4 text-foreground/90">{paragraph}</p>;
              }
              
              return paragraph.trim() && <p key={index} className="my-4 leading-relaxed">{paragraph}</p>;
            })}
          </div>
        </div>

        {/* Share Section */}
        <div className="border-t border-b py-6 mb-12">
          <div className="flex items-center justify-between">
            <span className="font-semibold">Share this article</span>
            <Button variant="outline" size="sm">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          </div>
        </div>

        {/* CTA Section */}
        <div className="p-8 rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-primary/5 border border-primary/30 mb-12">
          <h3 className="text-2xl font-bold mb-4">Ready to Put These Tips into Action?</h3>
          <p className="text-foreground/80 mb-6">
            Use ScriptAI to generate professional video scripts that incorporate these proven strategies. Get started with 3 free scripts today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/">
              <Button size="lg" className="gradient-bg" data-testid="button-try-scriptai">
                Try ScriptAI Free
              </Button>
            </Link>
            <Link href="/">
              <Button size="lg" variant="outline" className="border-primary/50">
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Pro
              </Button>
            </Link>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="mt-16">
            <h3 className="text-2xl font-bold mb-8">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {relatedPosts.map((relatedPost) => (
                <Link key={relatedPost.id} href={`/blog/${relatedPost.slug}`}>
                  <div className="border rounded-lg p-6 hover:shadow-lg transition-shadow cursor-pointer" data-testid={`card-related-${relatedPost.slug}`}>
                    <span className="text-xs px-2 py-1 bg-primary/10 text-primary rounded-full">
                      {relatedPost.category}
                    </span>
                    <h4 className="font-bold mt-4 mb-2 line-clamp-2">{relatedPost.title}</h4>
                    <p className="text-sm text-muted-foreground line-clamp-2">{relatedPost.excerpt}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mt-4">
                      <Clock className="w-3 h-3" />
                      <span>{relatedPost.readTime}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
