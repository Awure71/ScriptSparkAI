import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Mail, ArrowLeft, MessageSquare, Send, Crown } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      toast({
        title: "Message Sent!",
        description: "We'll get back to you within 24 hours.",
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-8" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <MessageSquare className="w-12 h-12 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold">Contact Us</h1>
          </div>
          <p className="text-lg text-foreground/80">
            Have a question? We'd love to hear from you. Send us a message and we'll respond as soon as possible.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-16 max-w-5xl">
        <div className="grid md:grid-cols-5 gap-12">
          
          {/* Contact Form */}
          <div className="md:col-span-3">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Your name"
                  data-testid="input-name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  placeholder="your.email@example.com"
                  data-testid="input-email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">Subject</Label>
                <Input
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  required
                  placeholder="What's this about?"
                  data-testid="input-subject"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                  rows={6}
                  placeholder="Tell us more..."
                  data-testid="textarea-message"
                />
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full gradient-bg"
                disabled={isSubmitting}
                data-testid="button-submit"
              >
                <Send className="w-4 h-4 mr-2" />
                {isSubmitting ? "Sending..." : "Send Message"}
              </Button>
            </form>
          </div>

          {/* Contact Info Sidebar */}
          <div className="md:col-span-2">
            <div className="bg-gradient-to-br from-primary/10 to-primary/5 p-8 rounded-2xl border border-primary/20 sticky top-8">
              <h3 className="text-xl font-bold mb-6">Get in Touch</h3>
              
              <div className="space-y-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <Mail className="w-5 h-5 text-primary" />
                    <h4 className="font-semibold">Email</h4>
                  </div>
                  <p className="text-foreground/80 pl-8">
                    support@scriptsparkai.org
                  </p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Response Time</h4>
                  <p className="text-foreground/80">
                    We typically respond within 24 hours during business days.
                  </p>
                </div>

                <div className="pt-6 border-t border-primary/20">
                  <h4 className="font-semibold mb-4">Quick Links</h4>
                  <div className="space-y-2">
                    <Link href="/privacy">
                      <a className="text-primary hover:underline block">Privacy Policy</a>
                    </Link>
                    <Link href="/terms">
                      <a className="text-primary hover:underline block">Terms of Service</a>
                    </Link>
                    <Link href="/about">
                      <a className="text-primary hover:underline block">About Us</a>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* FAQ Section */}
        <div className="mt-16 pt-16 border-t">
          <h2 className="text-2xl font-bold mb-8">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold mb-2">How does the free tier work?</h3>
              <p className="text-foreground/80">
                You get 3 free script generations per session. After that, upgrade to Pro for unlimited access at $5/month.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Can I cancel my subscription anytime?</h3>
              <p className="text-foreground/80">
                Yes! You can cancel your Pro subscription at any time from your account settings. No questions asked.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">What payment methods do you accept?</h3>
              <p className="text-foreground/80">
                We accept all major credit cards through our secure payment processor, Stripe.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Do you offer refunds?</h3>
              <p className="text-foreground/80">
                We don't offer refunds for partial months, but you can cancel anytime to avoid future charges.
              </p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-16 p-8 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-background border border-primary/20">
          <div className="flex items-center gap-3 mb-4">
            <Crown className="w-8 h-8 text-primary" />
            <h3 className="text-2xl font-bold">Have More Questions? Try ScriptAI Free!</h3>
          </div>
          <p className="text-muted-foreground mb-6 text-lg">
            Get instant answers by trying our AI-powered script generator. Start with 3 free scripts, then upgrade to Pro for unlimited access, priority support, and advanced features — just $5/month.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/">
              <Button size="lg" className="gradient-bg" data-testid="button-try-free">
                Try Free Now
              </Button>
            </Link>
            <Link href="/">
              <Button size="lg" variant="outline" className="border-primary/50" data-testid="button-learn-pro">
                Learn About Pro
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
