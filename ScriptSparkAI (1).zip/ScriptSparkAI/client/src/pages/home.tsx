import { Video, CheckCircle, Eye, ExternalLink, Lightbulb, WandSparkles, Copy, Download, ChevronDown, ChevronUp, Infinity, Globe, Headset, Crown, User, LogOut } from "lucide-react";
import ScriptGenerator from "../components/script-generator";
import ScriptDisplay from "../components/script-display";
import RecentScripts from "../components/recent-scripts";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth, useLogout, AuthDialog } from "../components/auth";
import { SubscriptionUpgrade } from "../components/subscription";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Link } from "wouter";

export default function Home() {
  const [sessionId, setSessionId] = useState<string>("");
  const [generatedScript, setGeneratedScript] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  
  const { data: authData } = useAuth();
  const logoutMutation = useLogout();

  useEffect(() => {
    // Generate or get session ID
    let storedSessionId = localStorage.getItem('scriptai-session');
    if (!storedSessionId) {
      storedSessionId = `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('scriptai-session', storedSessionId);
    }
    setSessionId(storedSessionId);
  }, []);

  const { data: usage } = useQuery({
    queryKey: ['/api/usage', sessionId],
    enabled: !!sessionId,
  });

  const scriptsUsed = (usage as any)?.scriptsUsed || 0;
  const scriptsRemaining = Math.max(0, 3 - scriptsUsed);

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center">
                <Video className="text-primary-foreground w-4 h-4" />
              </div>
              <span className="text-xl font-bold text-primary">ScriptAI</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <a href="#features" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-features">Features</a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing">Pricing</a>
              <Link href="/blog" className="text-muted-foreground hover:text-foreground transition-colors" data-testid="link-blog">Blog</Link>
            </div>
            
            <div className="flex items-center space-x-4">
              {authData?.user ? (
                <>
                  <div className="hidden sm:flex items-center text-sm">
                    {authData.user.subscriptionStatus === 'active' ? (
                      <div className="flex items-center gap-2 text-green-600">
                        <Crown className="h-4 w-4" />
                        <span>Pro Member</span>
                      </div>
                    ) : (
                      <>
                        <span className="text-muted-foreground">Free scripts left:</span>
                        <span className="ml-2 px-2 py-1 bg-primary text-primary-foreground rounded-full text-xs font-medium" data-testid="text-scripts-remaining">
                          {scriptsRemaining}/3
                        </span>
                      </>
                    )}
                  </div>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="outline" size="sm" data-testid="button-user-menu">
                        <User className="h-4 w-4 mr-2" />
                        {authData.user.username}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {authData.user.subscriptionStatus !== 'active' && (
                        <DropdownMenuItem onClick={() => setShowAuthDialog(true)} data-testid="menu-item-upgrade">
                          <Crown className="h-4 w-4 mr-2" />
                          Upgrade to Pro
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem onClick={() => logoutMutation.mutate()} data-testid="menu-item-logout">
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <>
                  <div className="hidden sm:flex items-center text-sm">
                    <span className="text-muted-foreground">Free scripts left:</span>
                    <span className="ml-2 px-2 py-1 bg-primary text-primary-foreground rounded-full text-xs font-medium" data-testid="text-scripts-remaining">
                      {scriptsRemaining}/3
                    </span>
                  </div>
                  <Button
                    onClick={() => setShowAuthDialog(true)}
                    data-testid="button-signup"
                  >
                    Sign Up
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-gradient py-16 px-4">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Create Viral Video Scripts 
            <span className="block">in Seconds</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Stop struggling with writer's block. Generate compelling video scripts and storyboards instantly.
          </p>
          <div className="flex flex-wrap justify-center gap-4 text-sm font-medium">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4" />
              <span>YouTube Optimized</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4" />
              <span>TikTok Ready</span>
            </div>
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4" />
              <span>Multilingual</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Generator Interface */}
      <section className="py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            
            {/* Input Section */}
            <ScriptGenerator 
              sessionId={sessionId}
              scriptsRemaining={scriptsRemaining}
              onGenerate={setGeneratedScript}
              onGeneratingChange={setIsGenerating}
            />

            {/* Output Preview Section */}
            <ScriptDisplay 
              script={generatedScript}
              isGenerating={isGenerating}
            />
          </div>
        </div>
      </section>

      {/* Recent Scripts Section */}
      <section className="py-12 px-4 bg-secondary/30">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">Recent Scripts</h2>
            <a href="#" className="text-primary hover:text-primary/80 font-medium" data-testid="link-view-all">View All</a>
          </div>
          
          <RecentScripts />
        </div>
      </section>

      {/* Pricing CTA */}
      <section className="py-16 px-4 gradient-bg text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Create Unlimited Scripts?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of creators who've gone viral with ScriptAI</p>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 max-w-md mx-auto">
            <div className="text-4xl font-bold mb-2">$5<span className="text-lg font-normal">/month</span></div>
            <p className="mb-6 opacity-90">Unlimited scripts, exports, and priority support</p>
            
            <button className="w-full bg-white text-primary py-4 rounded-lg font-semibold text-lg hover:bg-white/90 transition-colors mb-4" data-testid="button-free-trial">
              Start Free Trial
            </button>
            
            <p className="text-sm opacity-80">Cancel anytime • No setup fees</p>
          </div>

          <div className="mt-12 grid md:grid-cols-3 gap-8 text-sm">
            <div className="flex items-center justify-center space-x-2">
              <Infinity className="w-6 h-6" />
              <span>Unlimited Scripts</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <Globe className="w-6 h-6" />
              <span>All Languages</span>
            </div>
            <div className="flex items-center justify-center space-x-2">
              <Headset className="w-6 h-6" />
              <span>Priority Support</span>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 gradient-bg rounded-lg flex items-center justify-center">
                  <Video className="text-primary-foreground w-4 h-4" />
                </div>
                <span className="text-xl font-bold text-primary">ScriptAI</span>
              </div>
              <p className="text-muted-foreground text-sm">Generate viral video scripts and storyboards in seconds.</p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground" data-testid="link-features-footer">Features</a></li>
                <li><a href="#" className="hover:text-foreground" data-testid="link-pricing-footer">Pricing</a></li>
                <li><a href="#" className="hover:text-foreground" data-testid="link-examples-footer">Examples</a></li>
                <li><a href="#" className="hover:text-foreground" data-testid="link-api">API</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/blog" className="hover:text-foreground" data-testid="link-blog-footer">Blog</Link></li>
                <li><Link href="/contact" className="hover:text-foreground" data-testid="link-contact-footer">Contact</Link></li>
                <li><a href="#features" className="hover:text-foreground" data-testid="link-features-footer">Features</a></li>
                <li><a href="#" className="hover:text-foreground" data-testid="link-templates">Templates</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/about" className="hover:text-foreground" data-testid="link-about">About</Link></li>
                <li><Link href="/contact" className="hover:text-foreground" data-testid="link-contact">Contact</Link></li>
                <li><Link href="/privacy" className="hover:text-foreground" data-testid="link-privacy">Privacy</Link></li>
                <li><Link href="/terms" className="hover:text-foreground" data-testid="link-terms">Terms</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm text-muted-foreground">© 2024 ScriptAI. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <a href="#" className="text-muted-foreground hover:text-foreground" data-testid="link-twitter">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" data-testid="link-linkedin">
                <i className="fab fa-linkedin"></i>
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground" data-testid="link-youtube">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Authentication Dialog */}
      <Dialog open={showAuthDialog} onOpenChange={setShowAuthDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Join ScriptAI Pro</DialogTitle>
            <DialogDescription>
              Get unlimited script generation and access to all premium features for just $5/month.
            </DialogDescription>
          </DialogHeader>
          <AuthDialog onSuccess={(user) => {
            setShowAuthDialog(false);
          }} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
