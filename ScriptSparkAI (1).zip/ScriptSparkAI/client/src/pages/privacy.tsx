import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft, Crown } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-8" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <Shield className="w-12 h-12 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold">Privacy Policy</h1>
          </div>
          <p className="text-muted-foreground text-lg">Last updated: November 4, 2025</p>
          <p className="mt-4 text-lg">
            Your privacy is important to us. This policy explains how ScriptAI collects, uses, and protects your personal information.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-16 max-w-3xl">
        <div className="prose prose-lg max-w-none space-y-8">
          
          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              1. Information We Collect
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We collect information you provide directly to us when you:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Create an account (email address, password)</li>
              <li>Generate video scripts (topic, preferences)</li>
              <li>Subscribe to our Pro plan (payment information via Stripe)</li>
              <li>Contact us for support</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              2. How We Use Your Information
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We use the information we collect to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Provide, maintain, and improve our services</li>
              <li>Generate AI-powered video scripts based on your input</li>
              <li>Process payments and manage subscriptions</li>
              <li>Send you updates about your account and our services</li>
              <li>Respond to your comments and questions</li>
              <li>Detect and prevent fraud and abuse</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              3. Information Sharing
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We do not sell your personal information. We may share your information with:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li><strong>Service Providers:</strong> OpenAI for AI script generation, Stripe for payment processing</li>
              <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
              <li><strong>Business Transfers:</strong> In connection with a merger, sale, or acquisition</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              4. Cookies and Tracking
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We use cookies and similar tracking technologies to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Keep you logged in to your account</li>
              <li>Remember your preferences</li>
              <li>Understand how you use our service</li>
              <li>Improve our website performance</li>
            </ul>
            <p className="text-foreground/90 leading-relaxed mt-4">
              You can control cookies through your browser settings, but some features may not work properly if you disable them.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              5. Data Security
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We implement appropriate technical and organizational measures to protect your personal information, including:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Encryption of sensitive data in transit and at rest</li>
              <li>Secure password hashing using bcrypt</li>
              <li>Regular security assessments and updates</li>
              <li>Limited access to personal information</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              6. Your Rights
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              Depending on your location, you may have the right to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Access your personal information</li>
              <li>Correct inaccurate data</li>
              <li>Request deletion of your data</li>
              <li>Object to processing of your data</li>
              <li>Export your data</li>
              <li>Withdraw consent</li>
            </ul>
            <p className="text-foreground/90 leading-relaxed mt-4">
              To exercise these rights, please contact us at privacy@scriptsparkai.org
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              7. Children's Privacy
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              Our service is not intended for children under 13 years of age. We do not knowingly collect personal information from children under 13.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              8. Changes to This Policy
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the "Last updated" date.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              9. Contact Us
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              If you have any questions about this Privacy Policy, please contact us at:
            </p>
            <div className="bg-primary/5 border-l-4 border-primary p-6 rounded-r-lg mt-4">
              <p className="font-semibold">ScriptAI Support</p>
              <p className="text-foreground/90">Email: privacy@scriptsparkai.org</p>
              <p className="text-foreground/90">Website: scriptsparkai.org</p>
            </div>
          </section>

        </div>

        {/* CTA Section */}
        <div className="mt-16 p-8 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-background border border-primary/20">
          <div className="flex items-center gap-3 mb-4">
            <Crown className="w-8 h-8 text-primary" />
            <h3 className="text-2xl font-bold">Unlock Unlimited Creativity with Pro</h3>
          </div>
          <p className="text-muted-foreground mb-6 text-lg">
            Your data is secure with ScriptAI. Upgrade to Pro for unlimited script generation, priority support, and advanced AI features — all for just $5/month.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/">
              <Button size="lg" className="gradient-bg" data-testid="button-get-started">
                Try Free (3 Scripts)
              </Button>
            </Link>
            <Link href="/">
              <Button size="lg" variant="outline" className="border-primary/50" data-testid="button-upgrade-pro">
                Upgrade to Pro
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
