import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, ArrowLeft, Crown } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-br from-primary/10 via-primary/5 to-background py-20">
        <div className="container mx-auto px-6 max-w-4xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-8" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
          <div className="flex items-center gap-4 mb-6">
            <FileText className="w-12 h-12 text-primary" />
            <h1 className="text-4xl md:text-5xl font-bold">Terms of Service</h1>
          </div>
          <p className="text-muted-foreground text-lg">Last updated: November 4, 2025</p>
          <p className="mt-4 text-lg">
            Please read these terms carefully before using ScriptAI.
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-16 max-w-3xl">
        <div className="prose prose-lg max-w-none space-y-8">
          
          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              1. Acceptance of Terms
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              By accessing and using ScriptAI ("the Service"), you accept and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              2. Description of Service
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              ScriptAI is an AI-powered video script generation platform that helps content creators develop engaging scripts for social media videos. We offer:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li><strong>Free Tier:</strong> 3 script generations per session</li>
              <li><strong>Pro Subscription:</strong> Unlimited script generations for $5/month</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              3. User Accounts
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              To access certain features, you must create an account. You agree to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Provide accurate and complete information</li>
              <li>Maintain the security of your password</li>
              <li>Notify us immediately of any unauthorized access</li>
              <li>Be responsible for all activities under your account</li>
              <li>Be at least 13 years old (or 18 in some jurisdictions)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              4. Subscription and Payment
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              <strong>Pro Subscription:</strong>
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Billed monthly at $5/month via Stripe</li>
              <li>Automatically renews until cancelled</li>
              <li>Can be cancelled anytime from your account settings</li>
              <li>No refunds for partial months</li>
              <li>Price changes will be communicated 30 days in advance</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              5. Acceptable Use
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              You agree NOT to use the Service to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Generate content that is illegal, harmful, or violates others' rights</li>
              <li>Create misleading, defamatory, or harassing content</li>
              <li>Attempt to circumvent usage limits or security measures</li>
              <li>Reverse engineer or copy the Service</li>
              <li>Use automated tools to access the Service excessively</li>
              <li>Resell or redistribute generated content as a service</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              6. Intellectual Property
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              <strong>Your Content:</strong> You retain all rights to the video scripts you create using ScriptAI. You are free to use, modify, and monetize your generated scripts.
            </p>
            <p className="text-foreground/90 leading-relaxed mt-4">
              <strong>Our Service:</strong> ScriptAI, including its design, code, and underlying technology, is protected by copyright and other intellectual property laws. You may not copy, modify, or create derivative works.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              7. AI-Generated Content Disclaimer
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              Scripts are generated using AI technology. While we strive for quality:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Generated content may not always be accurate or appropriate</li>
              <li>You are responsible for reviewing and editing scripts before use</li>
              <li>We do not guarantee the originality of generated content</li>
              <li>You should verify facts and claims in generated scripts</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              8. Termination
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We may suspend or terminate your account if you:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-foreground/90">
              <li>Violate these Terms of Service</li>
              <li>Engage in fraudulent or illegal activity</li>
              <li>Abuse the Service or other users</li>
            </ul>
            <p className="text-foreground/90 leading-relaxed mt-4">
              You may cancel your account at any time from your account settings.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              9. Disclaimer of Warranties
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              THE SERVICE IS PROVIDED "AS IS" WITHOUT WARRANTIES OF ANY KIND. WE DO NOT GUARANTEE THAT THE SERVICE WILL BE UNINTERRUPTED, ERROR-FREE, OR SECURE.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              10. Limitation of Liability
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              TO THE MAXIMUM EXTENT PERMITTED BY LAW, SCRIPTAI SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES ARISING FROM YOUR USE OF THE SERVICE.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              11. Changes to Terms
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              We reserve the right to modify these terms at any time. Continued use of the Service after changes constitutes acceptance of the new terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              12. Contact Information
            </h2>
            <p className="text-foreground/90 leading-relaxed">
              For questions about these Terms, contact us at:
            </p>
            <div className="bg-primary/5 border-l-4 border-primary p-6 rounded-r-lg mt-4">
              <p className="font-semibold">ScriptAI Legal</p>
              <p className="text-foreground/90">Email: legal@scriptsparkai.org</p>
              <p className="text-foreground/90">Website: scriptsparkai.org</p>
            </div>
          </section>

        </div>

        {/* CTA Section */}
        <div className="mt-16 p-8 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-background border border-primary/20">
          <div className="flex items-center gap-3 mb-4">
            <Crown className="w-8 h-8 text-primary" />
            <h3 className="text-2xl font-bold">Ready to Create Viral Scripts?</h3>
          </div>
          <p className="text-muted-foreground mb-6 text-lg">
            By using ScriptAI, you agree to these terms. Start with 3 free scripts or upgrade to Pro for unlimited access, priority support, and advanced features — only $5/month.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/">
              <Button size="lg" className="gradient-bg" data-testid="button-get-started">
                Start Free Trial
              </Button>
            </Link>
            <Link href="/">
              <Button size="lg" variant="outline" className="border-primary/50" data-testid="button-upgrade-pro">
                Upgrade to Pro
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
