# ScriptAI Design Guidelines

## Design Approach

**Reference-Based Strategy**: Drawing inspiration from modern SaaS products (Linear, Notion) combined with creative tool aesthetics (Riverside.fm, Descript). The design balances professional credibility with creative energy, using the purple gradient as a signature brand element throughout.

**Core Principle**: Clean, content-forward layouts with strategic gradient accents that guide users toward conversion actions without overwhelming the interface.

---

## Typography System

**Font Families**:
- Primary: Inter (via Google Fonts) - clean, modern sans-serif for UI and body text
- Accent: Space Grotesk (via Google Fonts) - geometric, bold for headlines and feature callouts

**Hierarchy**:
- Hero Headlines: Space Grotesk, 56-64px desktop / 36-42px mobile, font-weight 700
- Section Headers: Space Grotesk, 40-48px desktop / 28-32px mobile, font-weight 600
- Subsection Titles: Inter, 24-28px, font-weight 600
- Body Text: Inter, 16-18px, font-weight 400, line-height 1.7
- Small Text/Captions: Inter, 14px, font-weight 400
- Button Text: Inter, 15-16px, font-weight 500, slight letter-spacing

---

## Layout System

**Spacing Primitives**: Tailwind units of 3, 4, 6, 8, 12, 16, 20, 24
- Component gaps: gap-6 to gap-8
- Section padding: py-20 to py-32 desktop, py-12 to py-16 mobile
- Container margins: px-6 to px-8

**Container Widths**:
- Max-width content: max-w-7xl (1280px)
- Text content: max-w-4xl (896px)
- Narrow content (blog posts): max-w-3xl (768px)

**Grid Systems**:
- Feature grids: 3 columns desktop (lg:grid-cols-3), 2 tablet (md:grid-cols-2), 1 mobile
- Blog cards: 3 columns desktop, 2 tablet, 1 mobile
- Testimonials: 2 columns desktop/tablet, 1 mobile

---

## Landing Page Structure

### Hero Section (80vh minimum)
Large hero image showing content creators or video production scenes with overlay gradient. Image placement: full-width background with gradient overlay for text legibility.

**Layout**: Single-column centered with max-w-4xl container
- Headline with gradient text treatment on key words ("AI-Powered")
- Subheadline (18-20px) explaining value proposition
- Dual CTA buttons: Primary "Start Creating Free" with gradient background + blur effect, Secondary "Watch Demo" ghost button
- Social proof strip below CTAs: "Trusted by 50,000+ creators" with small avatar stack
- Subtle animated gradient orbs floating in background (CSS animations only)

### Feature Showcase Section (py-24)
**Layout**: 3-column grid with icon cards
- Each card: gradient border effect, icon at top, title, 2-3 line description
- Features: "AI Script Generation", "Custom Templates", "Export Options", "Collaboration Tools", "SEO Optimization", "Multi-Platform Support"
- Hover effect: subtle lift and glow

### How It Works Section (py-20)
**Layout**: Alternating 2-column rows (image-text, text-image pattern)
- 3 steps total
- Left/right: Screenshot mockups with gradient border frames
- Opposite side: Step number (large gradient text), title, description, micro-feature bullets
- Step badges: Circular gradient backgrounds with numbers

### Pricing Section (py-24)
**Layout**: 2-column comparison (Free vs Pro)
**Pro card emphasized**: Gradient border, "Most Popular" badge, larger scale
- Feature comparison list with checkmarks
- Pricing: Large display of "$5/mo"
- CTA buttons: Pro gets gradient, Free gets outline
- Feature bullets highlighting Pro advantages: "Unlimited scripts", "Advanced AI models", "Priority support", "Custom templates", "Team collaboration"

### Testimonials Section (py-20)
**Layout**: 3-column grid of testimonial cards
- Each card: Quote, creator photo (circular), name, role, platform
- Gradient accent on left border of cards
- Mix of YouTubers, TikTokers, podcasters

### Final CTA Section (py-32)
**Layout**: Centered full-width with gradient background treatment
- Bold headline: "Ready to Transform Your Content?"
- Subtext about free trial
- Single prominent CTA button with blur background
- Small text: "No credit card required"

---

## Blog Section

### Blog Landing Page
**Hero**: Compact 40vh header with gradient background
- Title: "ScriptAI Insights"
- Subtitle: "Tips, tutorials, and trends in AI-powered content creation"

**Featured Post**: Full-width card with large thumbnail (16:9), gradient overlay, title overlaid on image, excerpt below

**Grid Layout**: 3-column article cards (max-w-7xl container)
- Card structure: Thumbnail (16:9 aspect), category badge (gradient background), title (2-line clamp), excerpt (3-line clamp), author info + date, read time
- Categories: "Tutorials", "Industry News", "Best Practices", "Creator Stories"
- Sidebar: Search bar, category filters, popular posts widget

### Individual Blog Post
**Layout**: Single column max-w-3xl
- Hero image: 21:9 aspect ratio with gradient border
- Title: Large Space Grotesk
- Meta info: Author avatar, name, date, read time
- Content: Generous line-height (1.8), styled headings with gradient accents
- Table of Contents: Sticky sidebar on desktop
- Related Posts: 3-column grid at bottom
- Newsletter CTA box: Gradient background, mid-article placement
- Social share buttons: Floating left side on desktop

---

## Legal Pages (Privacy, Terms, About, Contact)

### Privacy & Terms Layout
**Hero**: Minimal 30vh with gradient background
- Page title, last updated date
- Brief intro paragraph

**Content**: Single column max-w-3xl
- Clear section headers with gradient underlines
- Nested bullet lists for clarity
- Table of contents at top (jump links)
- Highlight boxes for important notices with subtle gradient borders

### About Page
**Hero**: 50vh with team/office image, gradient overlay
**Layout**: Mixed sections
- Company story: 2-column text blocks
- Mission statement: Centered full-width with gradient background
- Team grid: 4 columns (photos, names, roles)
- Company stats: 4-column metrics with gradient numbers

### Contact Page
**Layout**: 2-column split (60/40)
**Left**: Contact form
- Fields: Name, email, subject, message
- Gradient focus states on inputs
- Submit button with gradient background + blur

**Right**: Contact information card
- Office hours, email, social links
- Quick response promise
- FAQ accordion for common questions

---

## Component Library

### Buttons
- Primary: Gradient background, white text, px-8 py-3, rounded-xl
- Secondary: Outline with gradient border, gradient text
- Text buttons: Gradient text only
- All buttons: Smooth transitions, disabled states

### Cards
- Background: white/dark surface
- Border: 1px subtle or gradient
- Padding: p-6 to p-8
- Border-radius: rounded-xl to rounded-2xl
- Shadow: subtle on hover

### Form Inputs
- Height: h-12 to h-14
- Padding: px-4 to px-6
- Border-radius: rounded-lg
- Focus state: gradient border glow

### Navigation
**Desktop**: Horizontal bar, logo left, links center, CTA button right (gradient)
**Mobile**: Hamburger menu, full-screen overlay with gradient background
- Links: Inter 15px, medium weight
- Active state: gradient underline

### Footer
**Layout**: 4-column grid (Company, Product, Resources, Legal)
- Newsletter signup: Input + gradient button
- Social icons: Gradient on hover
- Bottom bar: Copyright, links

---

## Images Required

1. **Landing Hero**: Content creator recording video/podcast (landscape, 1920x1080)
2. **How It Works Screenshots**: 3 mockup images showing app interface (1200x800)
3. **Blog Featured Image**: AI/technology themed (1600x900)
4. **Blog Thumbnails**: 15-20 stock images (1200x675) - topics: video editing, content creation, AI tools
5. **About Hero**: Team or office environment (1920x800)
6. **Testimonial Avatars**: 9 creator headshots (400x400)

**Treatment**: All hero images use gradient overlays for text legibility. Feature screenshots use subtle gradient border frames.