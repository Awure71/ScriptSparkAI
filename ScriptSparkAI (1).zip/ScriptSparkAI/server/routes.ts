import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { scriptGenerationSchema, loginSchema, registerSchema } from "@shared/schema";
import { generateScript } from "./services/openai";
import { authenticateUser, registerUser, generateToken, requireAuth, checkSubscription } from "./services/auth";

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Stripe webhook - must be before express.json() middleware to get raw body
  app.post("/api/subscription/webhook", express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
      event = stripe.webhooks.constructEvent(req.body, sig!, process.env.STRIPE_WEBHOOK_SECRET!);
    } catch (err) {
      console.log(`Webhook signature verification failed.`, err);
      return res.status(400).send(`Webhook Error: ${err}`);
    }

    // Handle the event
    switch (event.type) {
      case 'checkout.session.completed':
        const session = event.data.object;
        if (session.metadata?.userId) {
          await storage.updateUserSubscription(session.metadata.userId, 'active', session.subscription as string);
        }
        break;
      case 'invoice.payment_succeeded':
        // Payment succeeded, ensure subscription is active
        const invoice = event.data.object;
        if (invoice.subscription && invoice.customer_email) {
          const user = await storage.getUserByEmail(invoice.customer_email as string);
          if (user) {
            await storage.updateUserSubscription(user.id, 'active', invoice.subscription as string);
          }
        }
        break;
      case 'invoice.payment_failed':
        // Payment failed, mark subscription as inactive
        const failedInvoice = event.data.object;
        if (failedInvoice.subscription && failedInvoice.customer_email) {
          const user = await storage.getUserByEmail(failedInvoice.customer_email as string);
          if (user) {
            await storage.updateUserSubscription(user.id, 'inactive', failedInvoice.subscription as string);
          }
        }
        break;
      default:
        console.log(`Unhandled event type ${event.type}`);
    }

    res.json({ received: true });
  });

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      const user = await registerUser(validatedData);
      const token = generateToken(user.id);
      
      res.cookie('auth_token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
      
      // Don't send back the password hash
      const { hashedPassword, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      if (error instanceof Error && error.message.includes("already exists")) {
        return res.status(409).json({ message: error.message });
      }
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Registration failed"
      });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body);
      const user = await authenticateUser(validatedData.email, validatedData.password);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      const token = generateToken(user.id);
      
      res.cookie('auth_token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
      });
      
      // Don't send back the password hash
      const { hashedPassword, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword, token });
    } catch (error) {
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Login failed"
      });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie('auth_token');
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", requireAuth(), async (req: any, res) => {
    const { hashedPassword, ...userWithoutPassword } = req.user;
    res.json({ user: userWithoutPassword });
  });

  // Subscription routes
  app.post("/api/subscription/create-checkout-session", requireAuth(), async (req: any, res) => {
    try {
      const session = await stripe.checkout.sessions.create({
        mode: 'subscription',
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: 'usd',
              product_data: {
                name: 'Video Script Generator Pro',
                description: 'Unlimited AI-generated video scripts for content creators',
              },
              unit_amount: 500, // $5.00
              recurring: {
                interval: 'month',
              },
            },
            quantity: 1,
          },
        ],
        success_url: `${req.headers.origin}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${req.headers.origin}/subscription/cancel`,
        customer_email: req.user.email,
        metadata: {
          userId: req.user.id,
        },
      });

      res.json({ sessionId: session.id });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create checkout session"
      });
    }
  });


  // Get usage for session
  app.get("/api/usage/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const usage = await storage.getUsageBySession(sessionId);
      res.json({ scriptsUsed: usage?.scriptsUsed || 0 });
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get usage data"
      });
    }
  });

  // Generate new script
  app.post("/api/scripts/generate", checkSubscription(), async (req: any, res) => {
    try {
      const validatedData = scriptGenerationSchema.parse(req.body);
      const { sessionId } = req.body;

      // Server-side subscription and quota enforcement
      if (req.user && req.hasUnlimitedAccess) {
        // Authenticated user with active subscription - unlimited access
        console.log(`Generating script for subscribed user: ${req.user.email}`);
      } else {
        // Free tier limits apply (both authenticated and non-authenticated users)
        if (!sessionId) {
          return res.status(400).json({ 
            message: "Session ID is required for free tier usage tracking"
          });
        }

        // Check usage limits for free users
        const usage = await storage.getUsageBySession(sessionId);
        if (usage && usage.scriptsUsed >= 3) {
          return res.status(429).json({ 
            message: req.user 
              ? "Free script limit reached. Upgrade to Pro for unlimited access."
              : "Free script limit reached. Sign up and subscribe to continue generating unlimited scripts.",
            scriptsUsed: usage.scriptsUsed,
            requiresAuth: !req.user, // Only require auth if not already authenticated
            requiresSubscription: !!req.user // Require subscription if authenticated but not subscribed
          });
        }
      }

      // Generate script using OpenAI
      const generatedScript = await generateScript(
        validatedData.topic,
        validatedData.duration,
        validatedData.language,
        validatedData.targetAudience,
        validatedData.tone
      );

      // Save script
      const script = await storage.createScript({
        topic: validatedData.topic,
        duration: validatedData.duration,
        language: validatedData.language,
        targetAudience: validatedData.targetAudience || null,
        tone: validatedData.tone,
        content: JSON.stringify(generatedScript.sections),
        storyboard: JSON.stringify(generatedScript.sections.map(s => s.visualPrompt)),
      });

      // Update usage
      const updatedUsage = await storage.createOrUpdateUsage(sessionId);

      res.json({
        script,
        generatedContent: generatedScript,
        scriptsUsed: updatedUsage.scriptsUsed
      });
    } catch (error) {
      if (error instanceof Error && error.message.includes("Free script limit")) {
        return res.status(429).json({ message: error.message });
      }
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to generate script"
      });
    }
  });

  // Get recent scripts
  app.get("/api/scripts/recent", async (req, res) => {
    try {
      const scripts = await storage.getRecentScripts(6);
      res.json(scripts);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get recent scripts"
      });
    }
  });

  // Get single script
  app.get("/api/scripts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const script = await storage.getScript(id);
      
      if (!script) {
        return res.status(404).json({ message: "Script not found" });
      }

      res.json(script);
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to get script"
      });
    }
  });

  // Export script
  app.get("/api/scripts/:id/export/:format", async (req, res) => {
    try {
      const { id, format } = req.params;
      const script = await storage.getScript(id);
      
      if (!script) {
        return res.status(404).json({ message: "Script not found" });
      }

      const sections = JSON.parse(script.content);
      
      switch (format) {
        case 'text':
          const textContent = sections.map((s: any) => 
            `${s.title} (${s.duration})\n${s.content}\n\nVisual: ${s.visualPrompt}\n`
          ).join('\n---\n\n');
          
          res.setHeader('Content-Type', 'text/plain');
          res.setHeader('Content-Disposition', `attachment; filename="${script.topic}_script.txt"`);
          res.send(textContent);
          break;
          
        case 'json':
          res.setHeader('Content-Type', 'application/json');
          res.setHeader('Content-Disposition', `attachment; filename="${script.topic}_script.json"`);
          res.json({
            topic: script.topic,
            duration: script.duration,
            language: script.language,
            sections
          });
          break;
          
        default:
          res.status(400).json({ message: "Unsupported export format" });
      }
    } catch (error) {
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to export script"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
