import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { storage } from "../storage";
import { type User, type InsertUser } from "@shared/schema";

// Ensure we have a secure JWT secret
const JWT_SECRET = process.env.SESSION_SECRET;
if (!JWT_SECRET) {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('SESSION_SECRET environment variable is required in production');
  }
  console.warn('WARNING: Using development JWT secret. Set SESSION_SECRET environment variable.');
}
const JWT_SECRET_TO_USE = JWT_SECRET || "dev-secret-change-in-production";
const JWT_EXPIRES_IN = "7d";

export interface AuthenticatedRequest extends Express.Request {
  user?: User;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function comparePassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}

export function generateToken(userId: string): string {
  return jwt.sign({ userId }, JWT_SECRET_TO_USE, { expiresIn: JWT_EXPIRES_IN });
}

export function verifyToken(token: string): { userId: string } | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET_TO_USE) as { userId: string };
    return decoded;
  } catch {
    return null;
  }
}

export async function authenticateUser(email: string, password: string): Promise<User | null> {
  const user = await storage.getUserByEmail(email);
  if (!user) {
    return null;
  }

  const isValid = await comparePassword(password, user.hashedPassword);
  if (!isValid) {
    return null;
  }

  return user;
}

export async function registerUser(userData: any): Promise<User> {
  // Check if user already exists
  const existingUser = await storage.getUserByEmail(userData.email);
  if (existingUser) {
    throw new Error("User already exists with this email");
  }

  // Hash password
  const hashedPassword = await hashPassword(userData.password);

  // Create user (exclude password from userData as it's not in InsertUser type)
  const { password, ...userDataWithoutPassword } = userData;
  const user = await storage.createUser({
    ...userDataWithoutPassword,
    hashedPassword,
  });

  return user;
}

export function authMiddleware() {
  return async (req: any, res: any, next: any) => {
    const token = req.cookies?.auth_token || req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      req.user = null;
      return next();
    }

    const decoded = verifyToken(token);
    if (!decoded) {
      req.user = null;
      return next();
    }

    try {
      const user = await storage.getUserById(decoded.userId);
      req.user = user || null;
    } catch {
      req.user = null;
    }

    next();
  };
}

export function requireAuth() {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };
}

export function checkSubscription() {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ message: "Authentication required" });
    }

    // Allow unlimited access for subscribers
    if (req.user.subscriptionStatus === 'active') {
      req.hasUnlimitedAccess = true;
    } else {
      req.hasUnlimitedAccess = false;
    }

    next();
  };
}