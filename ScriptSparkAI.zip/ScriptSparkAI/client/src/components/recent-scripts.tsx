import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Eye, ExternalLink } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";

export default function RecentScripts() {
  const { data: scripts, isLoading } = useQuery({
    queryKey: ['/api/scripts/recent'],
  });

  if (isLoading) {
    return (
      <div className="grid md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse" data-testid={`skeleton-script-${i}`}>
            <CardContent className="p-5">
              <div className="h-6 bg-muted rounded mb-3"></div>
              <div className="h-4 bg-muted rounded mb-2 w-3/4"></div>
              <div className="h-3 bg-muted rounded mb-4"></div>
              <div className="flex justify-between">
                <div className="h-3 bg-muted rounded w-16"></div>
                <div className="h-3 bg-muted rounded w-4"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!scripts || (scripts as any)?.length === 0) {
    return (
      <Card data-testid="empty-scripts">
        <CardContent className="p-8 text-center text-muted-foreground">
          <p>No scripts generated yet. Create your first viral script above!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-3 gap-6">
      {(scripts as any)?.map((script: any) => (
        <Card 
          key={script.id} 
          className="hover:shadow-md transition-shadow cursor-pointer"
          data-testid={`card-script-${script.id}`}
        >
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-3">
              <span className="bg-primary/10 text-primary px-2 py-1 rounded-full text-xs font-medium">
                {script.duration}
              </span>
              <span className="text-xs text-muted-foreground">
                {script.createdAt ? formatDistanceToNow(new Date(script.createdAt), { addSuffix: true }) : 'Recently'}
              </span>
            </div>
            <h3 className="font-semibold mb-2 line-clamp-2">{script.topic}</h3>
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {script.language} • {script.tone}
            </p>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                <Eye className="w-3 h-3" />
                <span>Script ready</span>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                className="text-primary hover:text-primary/80"
                data-testid={`button-view-script-${script.id}`}
              >
                <ExternalLink className="w-3 h-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
