import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { scriptGenerationSchema, type ScriptGenerationForm } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Lightbulb, WandSparkles, ChevronDown, ChevronUp, Crown, Zap } from "lucide-react";
import { useAuth, AuthDialog } from "./auth";

interface ScriptGeneratorProps {
  sessionId: string;
  scriptsRemaining: number;
  onGenerate: (script: any) => void;
  onGeneratingChange: (generating: boolean) => void;
}

export default function ScriptGenerator({ 
  sessionId, 
  scriptsRemaining, 
  onGenerate, 
  onGeneratingChange 
}: ScriptGeneratorProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: authData } = useAuth();

  const form = useForm<ScriptGenerationForm>({
    resolver: zodResolver(scriptGenerationSchema),
    defaultValues: {
      topic: "",
      duration: "60s",
      language: "English",
      targetAudience: "",
      tone: "Casual & Friendly",
    },
  });

  const generateMutation = useMutation({
    mutationFn: async (data: ScriptGenerationForm) => {
      const response = await apiRequest("POST", "/api/scripts/generate", {
        ...data,
        sessionId,
      });
      return await response.json();
    },
    onMutate: () => {
      onGeneratingChange(true);
    },
    onSuccess: (data) => {
      onGenerate(data);
      queryClient.invalidateQueries({ queryKey: ['/api/usage', sessionId] });
      queryClient.invalidateQueries({ queryKey: ['/api/scripts/recent'] });
      toast({
        title: "Script Generated!",
        description: `Your ${form.getValues('duration')} video script is ready.`,
      });
      form.reset();
    },
    onError: (error: any) => {
      // Check if this is a limit reached error that requires authentication
      if (error.message?.includes("Free script limit reached") && error.requiresAuth) {
        setShowAuthDialog(true);
        toast({
          title: "Upgrade Required",
          description: "Sign up for unlimited script generation starting at $5/month!",
          variant: "destructive",
        });
      } else {
        const message = error.message || "Failed to generate script";
        toast({
          title: "Generation Failed",
          description: message,
          variant: "destructive",
        });
      }
    },
    onSettled: () => {
      onGeneratingChange(false);
    },
  });

  const isSubscribed = authData?.user?.subscriptionStatus === 'active';
  const canGenerate = isSubscribed || scriptsRemaining > 0;

  const onSubmit = (data: ScriptGenerationForm) => {
    if (!canGenerate && !isSubscribed) {
      setShowAuthDialog(true);
      toast({
        title: "Upgrade Required",
        description: "Sign up for unlimited script generation starting at $5/month!",
        variant: "destructive",
      });
      return;
    }

    if (scriptsRemaining <= 0 && !isSubscribed) {
      setShowAuthDialog(true);
      toast({
        title: "Limit Reached",
        description: "You've used all your free scripts. Upgrade to continue.",
        variant: "destructive",
      });
      return;
    }
    generateMutation.mutate(data);
  };

  return (
    <>
    <Card className="shadow-sm" data-testid="card-script-generator">
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-6">Generate Your Script</h2>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Topic Input */}
          <div className="space-y-2">
            <Label htmlFor="topic" className="text-sm font-medium">Video Topic</Label>
            <div className="relative">
              <Input
                id="topic"
                placeholder="e.g., How to start a podcast in 2024"
                className="pr-10"
                data-testid="input-topic"
                {...form.register("topic")}
              />
              <Lightbulb className="absolute right-4 top-3 text-muted-foreground w-4 h-4" />
            </div>
            {form.formState.errors.topic && (
              <p className="text-sm text-destructive">{form.formState.errors.topic.message}</p>
            )}
          </div>

          {/* Duration Selection */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Video Duration</Label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: "60s", label: "60s", subtitle: "Short Form" },
                { value: "5min", label: "5 min", subtitle: "Medium" },
                { value: "10min", label: "10 min", subtitle: "Long Form" }
              ].map((duration) => (
                <button
                  key={duration.value}
                  type="button"
                  onClick={() => form.setValue("duration", duration.value as any)}
                  className={`p-4 border-2 rounded-lg text-center transition-colors ${
                    form.watch("duration") === duration.value
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary"
                  }`}
                  data-testid={`button-duration-${duration.value}`}
                >
                  <div className={`text-lg font-semibold ${
                    form.watch("duration") === duration.value ? "text-primary" : ""
                  }`}>
                    {duration.label}
                  </div>
                  <div className="text-xs text-muted-foreground">{duration.subtitle}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Language Selection */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Language</Label>
            <Select 
              value={form.watch("language")} 
              onValueChange={(value) => form.setValue("language", value as any)}
            >
              <SelectTrigger data-testid="select-language">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Spanish">Spanish</SelectItem>
                <SelectItem value="French">French</SelectItem>
                <SelectItem value="Hindi">Hindi</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Advanced Options */}
          <div className="space-y-3">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="flex items-center text-primary hover:text-primary/80 text-sm font-medium"
              data-testid="button-toggle-advanced"
            >
              {showAdvanced ? <ChevronUp className="w-4 h-4 mr-2" /> : <ChevronDown className="w-4 h-4 mr-2" />}
              Advanced Options
            </button>
            
            {showAdvanced && (
              <div className="space-y-4 pt-3">
                <div className="space-y-2">
                  <Label htmlFor="targetAudience" className="text-sm font-medium">Target Audience</Label>
                  <Input
                    id="targetAudience"
                    placeholder="e.g., Beginners, Tech enthusiasts"
                    data-testid="input-target-audience"
                    {...form.register("targetAudience")}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Tone</Label>
                  <Select 
                    value={form.watch("tone")} 
                    onValueChange={(value) => form.setValue("tone", value as any)}
                  >
                    <SelectTrigger data-testid="select-tone">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Casual & Friendly">Casual & Friendly</SelectItem>
                      <SelectItem value="Professional">Professional</SelectItem>
                      <SelectItem value="Energetic">Energetic</SelectItem>
                      <SelectItem value="Educational">Educational</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}
          </div>

          {/* Generate Button */}
          <Button
            type="submit"
            className="w-full gradient-bg text-primary-foreground py-4 text-lg font-semibold hover:opacity-90"
            disabled={generateMutation.isPending || (!canGenerate && !isSubscribed)}
            data-testid="button-generate-script"
          >
            <WandSparkles className="w-5 h-5 mr-2" />
            {generateMutation.isPending ? "Generating..." : "Generate Script & Storyboard"}
          </Button>

          <div className="space-y-2">
            {isSubscribed ? (
              <div className="flex items-center justify-center gap-2 text-sm text-green-600">
                <Crown className="h-4 w-4" />
                <span>Unlimited Pro Access</span>
              </div>
            ) : scriptsRemaining > 0 ? (
              <p className="text-xs text-muted-foreground text-center">
                {scriptsRemaining} free script{scriptsRemaining !== 1 ? 's' : ''} remaining
              </p>
            ) : (
              <div className="text-center space-y-2">
                <p className="text-xs text-orange-600">Free limit reached</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAuthDialog(true)}
                  className="text-xs"
                  data-testid="button-show-auth"
                >
                  <Crown className="h-3 w-3 mr-1" />
                  Upgrade for $5/month
                </Button>
              </div>
            )}
          </div>
        </form>
      </CardContent>
    </Card>

    {/* Authentication Dialog */}
    <Dialog open={showAuthDialog} onOpenChange={setShowAuthDialog}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Upgrade to Continue</DialogTitle>
          <DialogDescription>
            Sign up for unlimited script generation and access to all premium features.
          </DialogDescription>
        </DialogHeader>
        <AuthDialog onSuccess={(user) => {
          setShowAuthDialog(false);
          queryClient.invalidateQueries({ queryKey: ["auth"] });
        }} />
      </DialogContent>
    </Dialog>
    </>
  );
}
