import { loadStripe } from "@stripe/stripe-js";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Crown, Zap, Check, Loader2 } from "lucide-react";
import { useAuth } from "./auth";

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY!);

interface CheckoutSessionResponse {
  sessionId: string;
}

export function SubscriptionUpgrade() {
  const { toast } = useToast();
  const { data: authData, isLoading: authLoading } = useAuth();

  const createCheckoutSession = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/subscription/create-checkout-session");
      return await response.json();
    },
    onSuccess: async (response: CheckoutSessionResponse) => {
      const stripe = await stripePromise;
      if (!stripe) {
        throw new Error("Stripe failed to load");
      }

      const { error } = await stripe.redirectToCheckout({
        sessionId: response.sessionId,
      });

      if (error) {
        throw error;
      }
    },
    onError: (error: any) => {
      toast({
        title: "Payment error",
        description: error.message || "Failed to start payment process. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleUpgrade = () => {
    if (!authData?.user) {
      toast({
        title: "Please sign in",
        description: "You need to create an account before subscribing.",
        variant: "destructive",
      });
      return;
    }
    createCheckoutSession.mutate();
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const isSubscribed = authData?.user?.subscriptionStatus === 'active';

  if (isSubscribed) {
    return (
      <Card className="max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="flex items-center justify-center gap-2 text-green-600">
            <Crown className="h-5 w-5" />
            You're Pro!
          </CardTitle>
          <CardDescription>
            You have unlimited access to script generation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span className="text-sm">Unlimited script generation</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span className="text-sm">All languages supported</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="h-4 w-4 text-green-500" />
              <span className="text-sm">Priority customer support</span>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <Crown className="h-5 w-5 text-yellow-500" />
          Upgrade to Pro
        </CardTitle>
        <CardDescription>
          Unlock unlimited script generation for content creators
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center mb-6">
          <div className="text-3xl font-bold">$5<span className="text-lg font-normal text-muted-foreground">/month</span></div>
          <p className="text-sm text-muted-foreground mt-1">Cancel anytime</p>
        </div>
        
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-yellow-500" />
            <span className="text-sm">Unlimited AI-generated scripts</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm">All video durations (60s, 5min, 10min)</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm">Multi-language support</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm">Export to text & JSON formats</span>
          </div>
          <div className="flex items-center gap-2">
            <Check className="h-4 w-4 text-green-500" />
            <span className="text-sm">Priority customer support</span>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleUpgrade}
          disabled={createCheckoutSession.isPending || !authData?.user}
          className="w-full"
          data-testid="button-upgrade-subscription"
        >
          {createCheckoutSession.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {!authData?.user ? "Sign In to Subscribe" : "Upgrade Now"}
        </Button>
        {!authData?.user && (
          <p className="text-xs text-center text-muted-foreground mt-2">
            Please create an account first to subscribe
          </p>
        )}
      </CardFooter>
    </Card>
  );
}