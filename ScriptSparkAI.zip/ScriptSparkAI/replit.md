# ScriptAI - Viral Video Script Generator

## Overview

ScriptAI is a full-stack web application that generates viral video scripts using AI. The application allows users to create engaging scripts for social media videos of different durations (60 seconds, 5 minutes, 10 minutes) with customizable parameters like language, target audience, and tone. It features a modern React frontend with shadcn/ui components and an Express.js backend that integrates with OpenAI's API for script generation.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation for type-safe form management

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints for script generation and usage tracking
- **Validation**: Zod schemas shared between frontend and backend for consistent validation
- **Session Management**: Browser localStorage for simple session tracking
- **Error Handling**: Centralized error middleware with structured error responses

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL for cloud deployment
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Fallback Storage**: In-memory storage implementation for development/testing

### Authentication and Authorization
- **Session-based**: Simple session ID generation and storage in localStorage
- **Usage Limits**: Free tier with 3 scripts per session, tracked in database
- **No Authentication**: Public access model with session-based usage tracking

### External Dependencies
- **AI Integration**: OpenAI API (GPT-5) for script generation with structured prompts
- **Database**: Neon Database serverless PostgreSQL
- **Payment Processing**: Stripe integration (React Stripe.js) for potential premium features
- **Development Tools**: 
  - Replit-specific plugins for development environment
  - ESBuild for server bundling
  - PostCSS with Autoprefixer for CSS processing

### Key Design Patterns
- **Shared Schema**: Common TypeScript types and Zod schemas between client and server
- **Component Composition**: Modular React components with clear separation of concerns
- **API Abstraction**: Centralized API client with consistent error handling
- **Configuration Management**: Environment-based configuration with sensible defaults
- **Responsive Design**: Mobile-first approach with adaptive layouts

### Development Workflow
- **Hot Reload**: Vite HMR for frontend, tsx for backend development
- **Type Safety**: Full TypeScript coverage with strict configuration
- **Build Process**: Separate client and server builds with optimized production bundles
- **Database Operations**: Type-safe queries with Drizzle ORM and automatic migrations