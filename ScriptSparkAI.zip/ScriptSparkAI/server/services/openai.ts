import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "your-openai-key-here"
});

export interface ScriptSection {
  title: string;
  duration: string;
  content: string;
  visualPrompt: string;
}

export interface GeneratedScript {
  sections: ScriptSection[];
  totalDuration: string;
  wordCount: number;
}

export async function generateScript(
  topic: string,
  duration: string,
  language: string = "English",
  targetAudience?: string,
  tone: string = "Casual & Friendly"
): Promise<GeneratedScript> {
  const durationInSeconds = duration === "60s" ? 60 : duration === "5min" ? 300 : 600;
  
  // Development fallback when OpenAI API is unavailable or for testing
  if (process.env.NODE_ENV === "development") {
    console.log("Development mode: using mock script generation");
    return generateMockScript(topic, duration, language, targetAudience, tone);
  }
  
  const prompt = `Create a viral video script in ${language} about "${topic}" for a ${duration} video (${durationInSeconds} seconds).

Target Audience: ${targetAudience || "General audience"}
Tone: ${tone}

Structure the script with these sections based on duration:
${duration === "60s" 
  ? "- Hook (0-5s): Attention-grabbing opening\n- Introduction (5-15s): Quick intro and value proposition\n- Main Content (15-50s): Core information with quick tips\n- Call to Action (50-60s): Engagement request and follow"
  : duration === "5min"
  ? "- Hook (0-10s): Attention-grabbing opening\n- Introduction (10-30s): Detailed intro and what viewers will learn\n- Main Content (30-240s): Detailed information broken into digestible segments\n- Recap (240-270s): Quick summary of key points\n- Call to Action (270-300s): Strong CTA and engagement request"
  : "- Hook (0-15s): Strong attention-grabbing opening\n- Introduction (15-60s): Comprehensive intro and agenda\n- Main Content (60-480s): Detailed, well-structured content with examples\n- Deep Dive (480-540s): Advanced tips or detailed examples\n- Recap (540-570s): Comprehensive summary\n- Call to Action (570-600s): Strong CTA and next steps"
}

For each section, provide:
1. The script text (what to say)
2. Visual/storyboard prompts (what to show on screen)

Make the script engaging, actionable, and optimized for social media algorithms. Use proven viral video techniques like pattern interrupts, value delivery, and strong CTAs.

Return the response in JSON format with this structure:
{
  "sections": [
    {
      "title": "Section name",
      "duration": "0-5s",
      "content": "Script content to say",
      "visualPrompt": "Visual description for storyboard"
    }
  ],
  "totalDuration": "${duration}",
  "wordCount": 150
}`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are a viral video script expert who creates engaging, platform-optimized content for content creators. Always respond with valid JSON."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content!);
    return result;
  } catch (error) {
    // Fallback to mock if OpenAI fails (rate limits, etc.)
    console.warn("OpenAI API failed, using mock data:", error);
    return generateMockScript(topic, duration, language, targetAudience, tone);
  }
}

function generateMockScript(
  topic: string,
  duration: string,
  language: string = "English",
  targetAudience?: string,
  tone: string = "Casual & Friendly"
): GeneratedScript {
  const sections = duration === "60s" ? [
    {
      title: "Hook",
      duration: "0-5s",
      content: `¿Sabías que ${topic.toLowerCase()} puede cambiar tu vida? Quédate para descubrir los secretos que nadie te cuenta.`,
      visualPrompt: "Close-up of creator looking directly at camera, dynamic background with text overlay highlighting the main topic"
    },
    {
      title: "Introduction", 
      duration: "5-15s",
      content: `¡Hola! Soy tu guía para dominar ${topic.toLowerCase()}. En los próximos 60 segundos, te voy a revelar exactamente cómo empezar.`,
      visualPrompt: "Creator introduction with energetic gestures, topic-related graphics and icons floating around"
    },
    {
      title: "Main Content",
      duration: "15-50s", 
      content: `Aquí están los 3 pasos esenciales: 1) Define tu nicho y audiencia objetivo 2) Crea contenido de valor consistente 3) Optimiza para el algoritmo. Es así de simple pero efectivo.`,
      visualPrompt: "Split screen showing numbered steps, visual examples of each point, creator demonstrating with props or graphics"
    },
    {
      title: "Call to Action",
      duration: "50-60s",
      content: `¿Te gustó este contenido? Dale like, sígueme para más tips y comenta qué tema quieres que cubra próximamente. ¡Nos vemos en el siguiente video!`,
      visualPrompt: "Animated like button, subscribe notification, comment bubbles appearing, creator waving goodbye"
    }
  ] : duration === "5min" ? [
    {
      title: "Hook",
      duration: "0-10s", 
      content: `${language === "Spanish" ? "Este secreto sobre" : "This secret about"} ${topic.toLowerCase()} ${language === "Spanish" ? "me cambió la vida y te va a sorprender" : "changed my life and will surprise you"}`,
      visualPrompt: "Dramatic opening shot with engaging visual effects, creator with surprised expression"
    },
    {
      title: "Introduction",
      duration: "10-30s",
      content: `${language === "Spanish" ? "En este video completo te voy a enseñar todo sobre" : "In this complete video I'll teach you everything about"} ${topic.toLowerCase()}. ${language === "Spanish" ? "Desde los fundamentos hasta trucos avanzados que realmente funcionan" : "From fundamentals to advanced tricks that actually work"}.`,
      visualPrompt: "Creator presenting with confidence, topic overview graphics, preview of what's coming"
    },
    {
      title: "Main Content - Part 1",
      duration: "30-120s",
      content: `${language === "Spanish" ? "Primero, hablemos de los fundamentos. La clave está en entender que" : "First, let's talk fundamentals. The key is understanding that"} ${topic.toLowerCase()} ${language === "Spanish" ? "no es solo técnica, sino estrategia. Te explico paso a paso" : "isn't just technique, but strategy. I'll explain step by step"}.`,
      visualPrompt: "Detailed explanation with graphics, charts, or demonstrations relevant to the topic"
    },
    {
      title: "Main Content - Part 2", 
      duration: "120-240s",
      content: `${language === "Spanish" ? "Ahora viene la parte práctica. Estos son los errores que debes evitar y las estrategias que realmente funcionan para" : "Now comes the practical part. These are mistakes to avoid and strategies that really work for"} ${topic.toLowerCase()}.`,
      visualPrompt: "Practical examples, before/after comparisons, creator demonstrating techniques"
    },
    {
      title: "Recap",
      duration: "240-270s",
      content: `${language === "Spanish" ? "Para resumir: hemos cubierto los fundamentos, las estrategias clave y los errores comunes. Lo más importante es" : "To recap: we've covered fundamentals, key strategies and common mistakes. Most importantly"} ${language === "Spanish" ? "empezar hoy mismo" : "start today"}.`,
      visualPrompt: "Quick visual summary of main points, numbered list, creator emphasizing key takeaways"
    },
    {
      title: "Call to Action",
      duration: "270-300s", 
      content: `${language === "Spanish" ? "¿Qué te pareció? Comenta tu mayor duda, suscríbete para más contenido como este y comparte si te sirvió. ¡Hasta el próximo video!" : "What did you think? Comment your biggest question, subscribe for more content like this and share if it helped. Until the next video!"}`,
      visualPrompt: "Subscribe button animation, comment encouragement, social sharing graphics"
    }
  ] : [
    {
      title: "Hook",
      duration: "0-15s",
      content: `${language === "Spanish" ? "La guía definitiva sobre" : "The ultimate guide to"} ${topic.toLowerCase()} ${language === "Spanish" ? "que nadie te ha contado. Prepárate para 10 minutos que pueden cambiar tu perspectiva completamente" : "that nobody has told you. Get ready for 10 minutes that could completely change your perspective"}.`,
      visualPrompt: "Cinematic opening with dramatic music, creator in professional setting, topic graphics"
    },
    {
      title: "Introduction",
      duration: "15-60s", 
      content: `${language === "Spanish" ? "Bienvenidos a esta masterclass completa. Hoy vamos a profundizar en todo lo que necesitas saber sobre" : "Welcome to this complete masterclass. Today we're going deep into everything you need to know about"} ${topic.toLowerCase()}. ${language === "Spanish" ? "Cubriremos desde lo básico hasta estrategias avanzadas" : "We'll cover from basics to advanced strategies"}.`,
      visualPrompt: "Professional presentation setup, detailed agenda, creator establishing expertise"
    },
    {
      title: "Foundation",
      duration: "60-180s",
      content: `${language === "Spanish" ? "Empecemos con los fundamentos. La mayoría de la gente no entiende que" : "Let's start with foundations. Most people don't understand that"} ${topic.toLowerCase()} ${language === "Spanish" ? "requiere una base sólida. Te explico exactamente qué necesitas saber" : "requires a solid foundation. I'll explain exactly what you need to know"}.`,
      visualPrompt: "Detailed explanations with graphics, foundational concepts visualization"
    },
    {
      title: "Advanced Strategies",
      duration: "180-360s",
      content: `${language === "Spanish" ? "Ahora las estrategias avanzadas que separan a los principiantes de los expertos en" : "Now the advanced strategies that separate beginners from experts in"} ${topic.toLowerCase()}. ${language === "Spanish" ? "Estas técnicas son las que realmente marcan la diferencia" : "These techniques are what really make the difference"}.`,
      visualPrompt: "Advanced demonstrations, case studies, expert-level content visualization"
    },
    {
      title: "Deep Dive",
      duration: "360-480s",
      content: `${language === "Spanish" ? "Profundicemos en los casos específicos y ejemplos reales de cómo aplicar todo esto en" : "Let's dive deep into specific cases and real examples of how to apply all this in"} ${topic.toLowerCase()}. ${language === "Spanish" ? "Aquí es donde todo cobra sentido" : "This is where it all comes together"}.`,
      visualPrompt: "Real case studies, detailed examples, practical applications shown step by step"
    },
    {
      title: "Implementation",
      duration: "480-540s",
      content: `${language === "Spanish" ? "¿Cómo implementar todo esto? Te doy el plan de acción exacto que debes seguir para dominar" : "How to implement all this? I give you the exact action plan you should follow to master"} ${topic.toLowerCase()}. ${language === "Spanish" ? "Sin excusas, sin demoras" : "No excuses, no delays"}.`,
      visualPrompt: "Action plan graphics, step-by-step checklist, implementation timeline"
    },
    {
      title: "Summary & Next Steps",
      duration: "540-600s",
      content: `${language === "Spanish" ? "Hemos cubierto mucho terreno hoy. Los puntos clave para recordar sobre" : "We've covered a lot of ground today. Key points to remember about"} ${topic.toLowerCase()}: ${language === "Spanish" ? "fundamentos sólidos, estrategias avanzadas e implementación práctica. Tu próximo paso es empezar" : "solid foundations, advanced strategies and practical implementation. Your next step is to start"}.`,
      visualPrompt: "Comprehensive summary graphics, key takeaways, clear next steps presentation"
    }
  ];

  const wordCount = sections.reduce((total, section) => total + section.content.split(' ').length, 0);

  return {
    sections,
    totalDuration: duration,
    wordCount
  };
}
