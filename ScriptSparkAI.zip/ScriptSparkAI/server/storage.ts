import { type Script, type InsertScript, type UsageTracking, type InsertUsage, type User, type InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Script operations
  createScript(script: InsertScript): Promise<Script>;
  getScript(id: string): Promise<Script | undefined>;
  getRecentScripts(limit?: number): Promise<Script[]>;
  
  // User operations
  createUser(user: InsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserById(id: string): Promise<User | undefined>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User>;
  updateUserSubscriptionStatus(userId: string, status: string): Promise<User>;
  
  // Usage tracking
  getUsageBySession(sessionId: string): Promise<UsageTracking | undefined>;
  getUsageByUser(userId: string): Promise<UsageTracking | undefined>;
  createOrUpdateUsage(sessionId: string, userId?: string): Promise<UsageTracking>;
}

export class MemStorage implements IStorage {
  private scripts: Map<string, Script>;
  private usage: Map<string, UsageTracking>;
  private users: Map<string, User>;

  constructor() {
    this.scripts = new Map();
    this.usage = new Map();
    this.users = new Map();
  }

  async createScript(insertScript: InsertScript): Promise<Script> {
    const id = randomUUID();
    const script: Script = {
      id,
      topic: insertScript.topic,
      duration: insertScript.duration,
      language: insertScript.language || 'English',
      targetAudience: insertScript.targetAudience || null,
      tone: insertScript.tone || 'Casual & Friendly',
      content: insertScript.content,
      storyboard: insertScript.storyboard,
      createdAt: new Date(),
    };
    this.scripts.set(id, script);
    return script;
  }

  async getScript(id: string): Promise<Script | undefined> {
    return this.scripts.get(id);
  }

  async getRecentScripts(limit = 10): Promise<Script[]> {
    const allScripts = Array.from(this.scripts.values());
    return allScripts
      .sort((a, b) => b.createdAt!.getTime() - a.createdAt!.getTime())
      .slice(0, limit);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      subscriptionStatus: 'free',
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.email === email);
  }

  async getUserById(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId?: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    const updatedUser: User = {
      ...user,
      stripeCustomerId,
      stripeSubscriptionId: stripeSubscriptionId || user.stripeSubscriptionId,
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async updateUserSubscriptionStatus(userId: string, status: string): Promise<User> {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    const updatedUser: User = {
      ...user,
      subscriptionStatus: status,
    };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  async getUsageBySession(sessionId: string): Promise<UsageTracking | undefined> {
    return Array.from(this.usage.values()).find(u => u.sessionId === sessionId);
  }

  async getUsageByUser(userId: string): Promise<UsageTracking | undefined> {
    return Array.from(this.usage.values()).find(u => u.userId === userId);
  }

  async createOrUpdateUsage(sessionId: string, userId?: string): Promise<UsageTracking> {
    let existing: UsageTracking | undefined;
    
    if (userId) {
      existing = await this.getUsageByUser(userId);
    } else {
      existing = await this.getUsageBySession(sessionId);
    }
    
    if (existing) {
      const updated: UsageTracking = {
        ...existing,
        scriptsUsed: existing.scriptsUsed + 1,
        lastUsed: new Date(),
      };
      this.usage.set(existing.id, updated);
      return updated;
    } else {
      const id = randomUUID();
      const newUsage: UsageTracking = {
        id,
        userId: userId || null,
        sessionId: userId ? null : sessionId, // Use sessionId only for anonymous users
        scriptsUsed: 1,
        lastUsed: new Date(),
      };
      this.usage.set(id, newUsage);
      return newUsage;
    }
  }
}

export const storage = new MemStorage();
