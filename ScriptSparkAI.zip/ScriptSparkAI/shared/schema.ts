import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const scripts = pgTable("scripts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  topic: text("topic").notNull(),
  duration: text("duration").notNull(), // '60s', '5min', '10min'
  language: text("language").notNull().default('English'),
  targetAudience: text("target_audience"),
  tone: text("tone").default('Casual & Friendly'),
  content: text("content").notNull(), // JSON string of script sections
  storyboard: text("storyboard").notNull(), // JSON string of visual prompts
  createdAt: timestamp("created_at").defaultNow(),
});

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  username: text("username").notNull(),
  hashedPassword: text("hashed_password").notNull(),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  subscriptionStatus: text("subscription_status").default('free'), // 'free', 'active', 'canceled', 'past_due'
  createdAt: timestamp("created_at").defaultNow(),
});

export const usageTracking = pgTable("usage_tracking", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  sessionId: text("session_id"), // Keep for backwards compatibility
  scriptsUsed: integer("scripts_used").notNull().default(0),
  lastUsed: timestamp("last_used").defaultNow(),
});

export const insertScriptSchema = createInsertSchema(scripts).omit({
  id: true,
  createdAt: true,
});

export const insertUsageSchema = createInsertSchema(usageTracking).omit({
  id: true,
  lastUsed: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  stripeCustomerId: true,
  stripeSubscriptionId: true,
  subscriptionStatus: true,
});

export type Script = typeof scripts.$inferSelect;
export type InsertScript = z.infer<typeof insertScriptSchema>;
export type UsageTracking = typeof usageTracking.$inferSelect;
export type InsertUsage = z.infer<typeof insertUsageSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Frontend-only schemas for form validation
export const scriptGenerationSchema = z.object({
  topic: z.string().min(1, "Topic is required").max(200, "Topic must be under 200 characters"),
  duration: z.enum(["60s", "5min", "10min"]),
  language: z.enum(["English", "Spanish", "French", "Hindi"]).default("English"),
  targetAudience: z.string().optional(),
  tone: z.enum(["Casual & Friendly", "Professional", "Energetic", "Educational"]).default("Casual & Friendly"),
});

export type ScriptGenerationForm = z.infer<typeof scriptGenerationSchema>;

// Authentication schemas
export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
});

export const registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  username: z.string().min(2, "Username must be at least 2 characters").max(50, "Username must be under 50 characters"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export type LoginForm = z.infer<typeof loginSchema>;
export type RegisterForm = z.infer<typeof registerSchema>;
